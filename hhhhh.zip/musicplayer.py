from tkinter import *
from pygame import mixer
from tkinter.messagebox import showinfo
from tkinter import filedialog
import os
from mutagen.mp3 import MP3
root= Tk()
root.title("Play Music")
root.geometry("1000x600")
# root.minsize(1000,1000)
root.configure(bg='grey')
root.iconbitmap(r"icon.ico")


mixer.init()

def openfile():
    global filename
    filename= filedialog.askopenfilename()

def exit():
    root.destroy()
    
    
def about():
    showinfo("information", "Created by Priya")
    
    
l1=Label(root, text="refresh the your mood", bg="white", font=("arial",15,"bold"), width=20)
l1.place(x=370,y=100)

l2=Label(root, text="total length --:--", bg="white", font=("arial",15,"bold"), width=15)
l2.place(x=400,y=150)
    
def show_details():
    l1["text"]= "Playing" + " - "+os.path.basename(filename)
    
    filedata= os.path.splitext(filename)
    
    if filedata[1] == '.mp3':
        audio= MP3(filename)
        total_length= audio.info.length
    mins,secs = divmod(total_length,60)
    mins= round(mins)
    secs= round(secs)
    timeformat= "{:02d}:{:02d}".format(mins,secs)
    l2["text"]= "Total Length" + ' - '+ timeformat
    
    
def playmusic():
    global paused
    if paused:
        mixer.music.unpause()
        statusbar["text"]= "Resume Music"
        paused= FALSE
    else:
        try:
            mixer.music.load(filename)
            mixer.music.play()
            statusbar["text"]= "Playing Music"+"-"+os.path.basename(filename)
            show_details()
        except:
            tkinter.messagebox.showerror("error","File not found")
    
def stopmusic():
    mixer.music.stop()
    statusbar["text"]= "Stop Music"
    
def set_vol(val):
    volume= int(val)/100
    mixer.music.set_volume(volume)
    
paused= FALSE

def pause_music():
    global paused
    paused= True 
    mixer.music.pause()
    statusbar["text"]= "Pause Music"
    
def rewind_music():
    playmusic()
    statusbar["text"]= "Rewind Music"
    
muted = FALSE
def mute_music():
    global muted
    if muted:
        mixer.music.set_volume(0.7)
        volumebtn.configure(image= volumephoto)
        scale.set(70)
        muted= FALSE
    else:
        mixer.music.set_volume(0)
        volumebtn.configure(image= mutephoto)
        scale.set(0)
        muted= TRUE
middleframe= Frame(root)        
middleframe.pack(padx=10,pady=10)    
    
    

menubar= Menu(root)

# create filemenu

filemenu= Menu(menubar, tearoff=0)

filemenu.add_command(label="open", command=openfile)
filemenu.add_command(label="exit", command=exit)

menubar.add_cascade(label="file", menu=filemenu)

# create helpmenu

helpmenu= Menu(menubar, tearoff=0)

helpmenu.add_command(label="about", command=about)

menubar.add_cascade(label="help", menu=helpmenu)

root.config(menu= menubar)


# imglabel1= Label(root, image=clickbtn1)



playphoto= PhotoImage(file=r"play.png")
stopphoto= PhotoImage(file=r"stop.png")
pausephoto= PhotoImage(file=r"pause.png")
rewindphoto= PhotoImage(file=r"rewind.png")
mutephoto= PhotoImage(file=r"mute.png")
volumephoto= PhotoImage(file=r"volume.png")


playbtn= Button(root, image=playphoto, borderwidth=0, command=playmusic)
playbtn.place(x=200,y=250)

stopbtn= Button(root, image=stopphoto, borderwidth=0, command=stopmusic)
stopbtn.place(x=300,y=250)

pausebtn= Button(root, image=pausephoto, borderwidth=0, command=pause_music)
pausebtn.place(x=400,y=250)

rewindbtn= Button(root, image=rewindphoto, borderwidth=0, command=rewind_music)
rewindbtn.place(x=500,y=250)

volumebtn= Button(root, image=volumephoto, borderwidth=0, command=mute_music)
volumebtn.place(x=600,y=250)



scale=Scale(root, from_=0, to=100, orient=HORIZONTAL, command=set_vol)
scale.set(60)
scale.place(x=400,y=400)

statusbar= Label(root, text="Welcome to Music Player",bg="black", fg="white", relief="solid", anchor=W)
statusbar.pack(side=BOTTOM,fill=X)




root.mainloop()